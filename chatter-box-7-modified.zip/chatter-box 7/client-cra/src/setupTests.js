/**
 * Jest DOM Setup
 * Extends Jest with custom DOM element matchers
 */
import '@testing-library/jest-dom';
